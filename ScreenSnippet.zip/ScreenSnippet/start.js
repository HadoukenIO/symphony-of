var spawn = require('child_process').spawn
const path = require('path');

let snippetToolFilePath = path.join(__dirname, 'ScreenSnippet.js')

spawn(process.argv0, [snippetToolFilePath], {stdio: 'ignore', detached: true})
process.exit(0);